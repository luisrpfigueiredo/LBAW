$(".tagable").select2({
    tags: true,
    placeholder: 'Type Tag',
});