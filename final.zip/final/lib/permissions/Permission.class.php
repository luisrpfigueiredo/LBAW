<?php

abstract class Permission
{
    abstract function handle();
}
