<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 12:19:32
         compiled from "/home/vagrant/feup/LBAW/final/templates/answers/partials/answer_vote_panel.tpl" */ ?>
<?php /*%%SmartyHeaderCode:150204025457547f47cfa0d3-63653777%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bdc47b28d7f09fca79fdadb598ae642e7ca9ed26' => 
    array (
      0 => '/home/vagrant/feup/LBAW/final/templates/answers/partials/answer_vote_panel.tpl',
      1 => 1465301778,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '150204025457547f47cfa0d3-63653777',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_57547f47d05224_72170607',
  'variables' => 
  array (
    'answer' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57547f47d05224_72170607')) {function content_57547f47d05224_72170607($_smarty_tpl) {?><blockquote class="vote-up-down text-right">
    <div class="vote chev" data-type="a" data-id="<?php echo $_smarty_tpl->tpl_vars['answer']->value['id'];?>
" data-url="<?php echo url('api/votes/vote');?>
">

        <div class="increment up<?php if ($_smarty_tpl->tpl_vars['answer']->value['voted']==1) {?> active<?php }?>"></div>
        <div class="increment down<?php if ($_smarty_tpl->tpl_vars['answer']->value['voted']==-1) {?> active<?php }?>"></div>

        <div class="count vote-count value" data-url="<?php echo url('api/votes/refresh');?>
">
            <?php echo $_smarty_tpl->tpl_vars['answer']->value['votes'];?>

        </div>
    </div>

</blockquote><?php }} ?>
