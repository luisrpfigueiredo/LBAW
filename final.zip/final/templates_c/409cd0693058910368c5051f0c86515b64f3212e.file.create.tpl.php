<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 03:41:53
         compiled from "/home/vagrant/feup/LBAW/final/templates/answers/create.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14347912457545353a0a0c1-27046135%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '409cd0693058910368c5051f0c86515b64f3212e' => 
    array (
      0 => '/home/vagrant/feup/LBAW/final/templates/answers/create.tpl',
      1 => 1465270912,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14347912457545353a0a0c1-27046135',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_57545353a182b4_73297454',
  'variables' => 
  array (
    'BASE_URL' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57545353a182b4_73297454')) {function content_57545353a182b4_73297454($_smarty_tpl) {?><div class = "container">
    <div class = "panel panel-default">
        <div class = "panel-heading">
            <h3 class = "panel-title">Respond</h3>
        </div>
        <div class = "panel-body">
            <form class = "form-horizontal" method="post" action = "<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/answers/create.php">

                <?php echo $_smarty_tpl->getSubTemplate ('answers/partials/answer_form.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


                <div class = "form-group">
                    <div class = "col-sm-3 col-sm-offset-3 pull-right">
                        <button class = "btn btn-primary " type = "submit">Answer</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div><?php }} ?>
