<?php /* Smarty version Smarty-3.1.15, created on 2016-05-20 14:24:50
         compiled from "/home/vagrant/feup/LBAW/final/templates/common/breadcrumb.tpl" */ ?>
<?php /*%%SmartyHeaderCode:270233897573f1e3261a2f1-90836055%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fbe4312bf9463d005344a1d981050e8bb65c6a8a' => 
    array (
      0 => '/home/vagrant/feup/LBAW/final/templates/common/breadcrumb.tpl',
      1 => 1461896827,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '270233897573f1e3261a2f1-90836055',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_573f1e3262e176_16873102',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_573f1e3262e176_16873102')) {function content_573f1e3262e176_16873102($_smarty_tpl) {?><ol class = "breadcrumb">
    <li><a href = "#">Home</a></li>
    <li><a href = "#">Library</a></li>
    <li class = "active">Data</li>
</ol><?php }} ?>
