<?php /* Smarty version Smarty-3.1.15, created on 2016-06-05 16:41:24
         compiled from "/home/vagrant/feup/LBAW/final/templates/common/menu_logged_in.tpl" */ ?>
<?php /*%%SmartyHeaderCode:767575051573f1e2d7a91f8-02906248%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '234b481ea76171d95525e3e12ab09e81d48d2e56' => 
    array (
      0 => '/home/vagrant/feup/LBAW/final/templates/common/menu_logged_in.tpl',
      1 => 1464972741,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '767575051573f1e2d7a91f8-02906248',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_573f1e2d7c96d2_47500091',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_573f1e2d7c96d2_47500091')) {function content_573f1e2d7c96d2_47500091($_smarty_tpl) {?><li class = "cl-effect-21"><a href = "<?php echo url('pages/questions/create');?>
">Ask Question</a></li>
<li class = "cl-effect-21"><a href = "<?php echo url('pages/questions/list');?>
">Questions</a></li>
<li class = "cl-effect-21"><a href = "<?php echo url('pages/about');?>
">About Us</a></li>
<li class = " cl-effect-21"><a href = "<?php echo url('pages/users/profile');?>
">Profile</a></li>
<li class = "cl-effect-21"><a href = "<?php echo url('actions/users/logout');?>
">Log Out</a></li><?php }} ?>
