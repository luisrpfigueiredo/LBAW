<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 12:25:34
         compiled from "/home/vagrant/feup/LBAW/final/templates/questions/details.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1957453440573f2f1ac61fc9-10152679%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b5de37b9e379e31cfa90b06537a8eb1c37db41ec' => 
    array (
      0 => '/home/vagrant/feup/LBAW/final/templates/questions/details.tpl',
      1 => 1465302331,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1957453440573f2f1ac61fc9-10152679',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_573f2f1ac96604_89592895',
  'variables' => 
  array (
    'answers' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_573f2f1ac96604_89592895')) {function content_573f2f1ac96604_89592895($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('common/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<div class="container" style="margin-top: 2em">
    <?php echo $_smarty_tpl->getSubTemplate ('common/breadcrumb.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    <h1>Question Details</h1>
    <div class="question_space">
        <?php echo $_smarty_tpl->getSubTemplate ("questions/partials/question_info.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    </div>

    <div class="answer_space ">

        <?php  $_smarty_tpl->tpl_vars['answer'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['answer']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['answers']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['answer']->key => $_smarty_tpl->tpl_vars['answer']->value) {
$_smarty_tpl->tpl_vars['answer']->_loop = true;
?>
            <?php echo $_smarty_tpl->getSubTemplate ("answers/partials/answer_info.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

        <?php } ?>

        <?php echo $_smarty_tpl->getSubTemplate ("answers/create.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    </div>


</div>

<?php echo HTML::script('app/answers.js');?>


<?php echo $_smarty_tpl->getSubTemplate ('common/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>
