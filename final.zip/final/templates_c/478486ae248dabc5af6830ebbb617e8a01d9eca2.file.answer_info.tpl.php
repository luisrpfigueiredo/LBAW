<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 12:37:36
         compiled from "/home/vagrant/feup/LBAW/final/templates/answers/partials/answer_info.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1994753906575453f6218575-93668266%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '478486ae248dabc5af6830ebbb617e8a01d9eca2' => 
    array (
      0 => '/home/vagrant/feup/LBAW/final/templates/answers/partials/answer_info.tpl',
      1 => 1465303052,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1994753906575453f6218575-93668266',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_575453f6259be3_71525387',
  'variables' => 
  array (
    'answer' => 0,
    'LOGGED_IN' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_575453f6259be3_71525387')) {function content_575453f6259be3_71525387($_smarty_tpl) {?><div class = "col-sm-11 container-white answer-info-container  pull-right sizeSelector" data-id="<?php echo $_smarty_tpl->tpl_vars['answer']->value['id'];?>
">
    <div class = "col-sm-2">
        <?php $_smarty_tpl->tpl_vars['votable_type'] = new Smarty_variable('a', null, 0);?>
        <?php if ($_smarty_tpl->tpl_vars['LOGGED_IN']->value) {?>
            <?php echo $_smarty_tpl->getSubTemplate ("answers/partials/answer_vote_panel.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

        <?php } else { ?>

            <?php echo $_smarty_tpl->getSubTemplate ("questions/partials/show_count.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

        <?php }?>
    </div>

    <div class = "col-sm-10">
        <p class = "answer-description">
            <?php echo nl2br($_smarty_tpl->tpl_vars['answer']->value['body']);?>

        </p>

        <div class = "options pull-right<?php if (!$_smarty_tpl->tpl_vars['answer']->value['isMine']) {?> hidden<?php }?>">
            <button class = "btn btn-primary btn-xs edit-answer" data-url = "<?php echo editAnswerUrl('');?>
">Edit</button>
        </div>
    </div>

    <div class = "statistics col-sm-12 text-center">
        <span>
            <i class = "glyphicon glyphicon-user"></i>
            <a href = "<?php echo profileUrl($_smarty_tpl->tpl_vars['answer']->value['user_id']);?>
" class = "question-body question-title"">
                <?php echo $_smarty_tpl->tpl_vars['answer']->value['username'];?>

            </a>
        </span>
        <span>
            <i class = "glyphicon glyphicon-time"></i>
            <span class = "answer-updated-at">
                <?php if ($_smarty_tpl->tpl_vars['answer']->value['updated_at']) {?>
                    <?php echo $_smarty_tpl->tpl_vars['answer']->value['updated_at'];?>

                <?php } else { ?>
                    <?php echo $_smarty_tpl->tpl_vars['answer']->value['created_at'];?>

                <?php }?></span>
        </span>

    </div>
</div><?php }} ?>
