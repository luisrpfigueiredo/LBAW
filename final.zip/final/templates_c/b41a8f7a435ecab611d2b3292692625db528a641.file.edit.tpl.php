<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 12:34:35
         compiled from "/home/vagrant/feup/LBAW/final/templates/answers/edit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13081611855756be01bf3775-65821736%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b41a8f7a435ecab611d2b3292692625db528a641' => 
    array (
      0 => '/home/vagrant/feup/LBAW/final/templates/answers/edit.tpl',
      1 => 1465302631,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13081611855756be01bf3775-65821736',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_5756be01c24f94_68941028',
  'variables' => 
  array (
    'BASE_URL' => 0,
    'answer' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5756be01c24f94_68941028')) {function content_5756be01c24f94_68941028($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('common/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<div class = "container">
    <?php echo $_smarty_tpl->getSubTemplate ('common/breadcrumb.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


    <div class = "panel panel-default">
        <div class = "panel-heading">
            <h3 class = "panel-title">Edit Answer</h3>
        </div>
        <div class = "panel-body">
            <form class = "form-horizontal" method = "post" action = "<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/answers/edit.php">

                <input type = "hidden" name = "answer_id" value = "<?php echo $_smarty_tpl->tpl_vars['answer']->value['id'];?>
">

                <div class = "form-group">
                    <div class = "col-sm-12 ">
                        <textarea id="answerBody" class = "form-control" rows = "5"  name = "body"><?php echo $_smarty_tpl->tpl_vars['answer']->value['body'];?>
</textarea>
                    </div>
                </div>

                <div class = "form-group">
                    <div class = "col-sm-12 text-center">
                        <button class = "btn btn-primary" type = "submit">Edit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ('common/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>
