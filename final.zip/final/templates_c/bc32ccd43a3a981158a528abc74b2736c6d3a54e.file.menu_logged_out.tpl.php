<?php /* Smarty version Smarty-3.1.15, created on 2016-06-03 16:53:31
         compiled from "/home/vagrant/feup/LBAW/final/templates/common/menu_logged_out.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1964253978573f194280f263-69011399%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bc32ccd43a3a981158a528abc74b2736c6d3a54e' => 
    array (
      0 => '/home/vagrant/feup/LBAW/final/templates/common/menu_logged_out.tpl',
      1 => 1464972803,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1964253978573f194280f263-69011399',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_573f1942821702_83179967',
  'variables' => 
  array (
    'tab' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_573f1942821702_83179967')) {function content_573f1942821702_83179967($_smarty_tpl) {?><li class="cl-effect-21"><a href="<?php echo url('pages/questions/list');?>
">Questions</a></li>
<li class="cl-effect-21"><a href="<?php echo url('pages/about');?>
">About Us</a></li>
<li class="cl-effect-21 <?php if (isset($_smarty_tpl->tpl_vars['tab']->value)) {?>active<?php }?>"><a href="<?php echo url('pages/users/authentication');?>
">Join us</a></li>
<?php }} ?>
