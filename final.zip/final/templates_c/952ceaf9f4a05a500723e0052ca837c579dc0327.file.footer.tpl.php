<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 11:51:41
         compiled from "/home/vagrant/feup/LBAW/final/templates/common/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:264701089573f1942c6deb7-99772901%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '952ceaf9f4a05a500723e0052ca837c579dc0327' => 
    array (
      0 => '/home/vagrant/feup/LBAW/final/templates/common/footer.tpl',
      1 => 1465300300,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '264701089573f1942c6deb7-99772901',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_573f1942ca25f7_68191879',
  'variables' => 
  array (
    'SUCCESS_MESSAGES' => 0,
    'message' => 0,
    'ERROR_MESSAGES' => 0,
    'LOGGED_IN' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_573f1942ca25f7_68191879')) {function content_573f1942ca25f7_68191879($_smarty_tpl) {?><?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['SUCCESS_MESSAGES']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
    <div class = "alert alert-success alert-dismissible" role = "alert">
        <button type = "button" class = "close" data-dismiss = "alert" aria-label = "Close">
            <span aria-hidden = "true">&times;</span></button>
        <strong>Success!</strong> <?php echo $_smarty_tpl->tpl_vars['message']->value;?>

    </div>
<?php } ?>
<?php  $_smarty_tpl->tpl_vars['message'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['message']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ERROR_MESSAGES']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['message']->key => $_smarty_tpl->tpl_vars['message']->value) {
$_smarty_tpl->tpl_vars['message']->_loop = true;
?>
    <div class = "alert alert-danger alert-dismissible" role = "alert">
        <button type = "button" class = "close" data-dismiss = "alert" aria-label = "Close">
            <span aria-hidden = "true">&times;</span></button>
        <strong>Danger!</strong> <?php echo $_smarty_tpl->tpl_vars['message']->value;?>

    </div>
<?php } ?>
<br class = "clearfix">

<?php if ($_smarty_tpl->tpl_vars['LOGGED_IN']->value) {?>
    <?php echo HTML::script('app/questions-info.js');?>

    <?php echo HTML::script('votes/myVoting.js');?>

<?php }?>
</body>
</html><?php }} ?>
