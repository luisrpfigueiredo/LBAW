<?php /* Smarty version Smarty-3.1.15, created on 2016-06-05 19:34:09
         compiled from "/home/vagrant/feup/LBAW/final/templates/questions/partials/vote_panel.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2113380337573f1942ba1c58-06555730%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f1eb34558071512ac6e08aa62264419180b7d475' => 
    array (
      0 => '/home/vagrant/feup/LBAW/final/templates/questions/partials/vote_panel.tpl',
      1 => 1465155248,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2113380337573f1942ba1c58-06555730',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_573f1942bcd3d4_58235586',
  'variables' => 
  array (
    'question' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_573f1942bcd3d4_58235586')) {function content_573f1942bcd3d4_58235586($_smarty_tpl) {?><blockquote class="vote-up-down text-right">
    <div class="vote chev">
        <div class="increment up"></div>
        <div class="increment down"></div>

        <div class="count vote-count" id="value">
            <?php echo $_smarty_tpl->tpl_vars['question']->value['votes'];?>

        </div>
    </div>

</blockquote><?php }} ?>
