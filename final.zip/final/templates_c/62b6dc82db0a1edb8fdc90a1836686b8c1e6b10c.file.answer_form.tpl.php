<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 02:37:55
         compiled from "/home/vagrant/feup/LBAW/final/templates/answers/partials/answer_form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:146131340857545353a54d77-93173736%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '62b6dc82db0a1edb8fdc90a1836686b8c1e6b10c' => 
    array (
      0 => '/home/vagrant/feup/LBAW/final/templates/answers/partials/answer_form.tpl',
      1 => 1465266882,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '146131340857545353a54d77-93173736',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_57545353a5f235_62561664',
  'variables' => 
  array (
    'question' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57545353a5f235_62561664')) {function content_57545353a5f235_62561664($_smarty_tpl) {?>
<div class = "form-group">

    <div class = "col-sm-12 ">
        <textarea id="answerBody" class = "form-control" rows = "5"  name = "body"></textarea>
    </div>
</div>

<div class = "form-group ">
    <input type="hidden" name = "question_id" value="<?php echo $_smarty_tpl->tpl_vars['question']->value['id'];?>
">
</div>
<?php }} ?>
