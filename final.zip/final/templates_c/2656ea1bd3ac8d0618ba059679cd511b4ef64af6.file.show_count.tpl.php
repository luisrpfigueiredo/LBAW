<?php /* Smarty version Smarty-3.1.15, created on 2016-06-05 16:41:19
         compiled from "/home/vagrant/feup/LBAW/final/templates/questions/partials/show_count.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1168865478575452ddaea802-24406511%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2656ea1bd3ac8d0618ba059679cd511b4ef64af6' => 
    array (
      0 => '/home/vagrant/feup/LBAW/final/templates/questions/partials/show_count.tpl',
      1 => 1465144823,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1168865478575452ddaea802-24406511',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_575452ddafe856_76209820',
  'variables' => 
  array (
    'votable_type' => 0,
    'question' => 0,
    'answer' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_575452ddafe856_76209820')) {function content_575452ddafe856_76209820($_smarty_tpl) {?><blockquote class="vote-up-down text-right">
    <div class="vote chev">

        <div class="count vote-count">
	        <?php if ($_smarty_tpl->tpl_vars['votable_type']->value==='q') {?>
	            <?php echo $_smarty_tpl->tpl_vars['question']->value['votes'];?>

	        <?php } else { ?>
	            <?php echo $_smarty_tpl->tpl_vars['answer']->value['votes'];?>

	        <?php }?>
        </div>

    </div>
</blockquote><?php }} ?>
