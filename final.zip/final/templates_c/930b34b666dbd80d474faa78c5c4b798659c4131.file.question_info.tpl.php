<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 12:38:03
         compiled from "/home/vagrant/feup/LBAW/final/templates/questions/partials/question_info.tpl" */ ?>
<?php /*%%SmartyHeaderCode:130734480573f19429c61a0-52628651%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '930b34b666dbd80d474faa78c5c4b798659c4131' => 
    array (
      0 => '/home/vagrant/feup/LBAW/final/templates/questions/partials/question_info.tpl',
      1 => 1465303082,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '130734480573f19429c61a0-52628651',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_573f1942a63574_11702699',
  'variables' => 
  array (
    'question' => 0,
    'LOGGED_IN' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_573f1942a63574_11702699')) {function content_573f1942a63574_11702699($_smarty_tpl) {?><div class = "col-sm-12 container-white question-info-container" data-id="<?php echo $_smarty_tpl->tpl_vars['question']->value['id'];?>
">

    <div class = "col-sm-2">
        <?php $_smarty_tpl->tpl_vars['votable_type'] = new Smarty_variable('q', null, 0);?>
        <?php if ($_smarty_tpl->tpl_vars['LOGGED_IN']->value) {?>
            <?php echo $_smarty_tpl->getSubTemplate ("questions/partials/question_vote_panel.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

        <?php } else { ?>
            <?php echo $_smarty_tpl->getSubTemplate ("questions/partials/show_count.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

        <?php }?>
    </div>
    <div class = "col-sm-10">
        <h3>
            <a href = "<?php echo questionUrl($_smarty_tpl->tpl_vars['question']->value['id']);?>
" class = "question-title" data-base-question-url = "<?php echo questionUrl('');?>
">
                <?php echo $_smarty_tpl->tpl_vars['question']->value['title'];?>

            </a>
        </h3>
        <p class = "question-description">
            <a href = "<?php echo questionUrl($_smarty_tpl->tpl_vars['question']->value['id']);?>
" class = "question-body" data-base-question-url = "<?php echo questionUrl('');?>
">
                <?php echo nl2br($_smarty_tpl->tpl_vars['question']->value['body']);?>

            </a>
        </p>
        <div class = "options pull-right<?php if (!$_smarty_tpl->tpl_vars['question']->value['isMine']) {?> hidden<?php }?>" style = "margin-bottom:5px;">
            <button class = "btn btn-primary btn-xs edit-question" data-url = "<?php echo editQuestionUrl('');?>
">Edit</button>
            <button class = "btn btn-success btn-xs trigger-question-solved<?php if ($_smarty_tpl->tpl_vars['question']->value['solved']) {?> hidden<?php }?>"
            data-url="<?php echo questionSolvedUrl('');?>
">Mark as solved</button>
        </div>
    </div>

    <div class = "statistics col-sm-12 text-center">
        <span>
            <i class = "glyphicon glyphicon-user"></i>
             <a href = "<?php echo profileUrl($_smarty_tpl->tpl_vars['question']->value['user_id']);?>
" class = "question-user" data-url = "<?php echo profileUrl('');?>
">
                <?php echo $_smarty_tpl->tpl_vars['question']->value['username'];?>

            </a>
        </span>
        <?php if ($_smarty_tpl->tpl_vars['question']->value['solved']) {?>
            <span class = "text-success question-solved-status">
                <i class = "glyphicon glyphicon-check"></i>
                <span>Solved</span>
            </span>
        <?php } else { ?>
            <span class = "text-danger question-solved-status">
                <i class = "glyphicon glyphicon-check"></i>
                <span>Not Solved</span>
            </span>
        <?php }?>
        <span>
            <i class = "glyphicon glyphicon-time"></i>
            <span class = "question-updated-at">
                <?php if ($_smarty_tpl->tpl_vars['question']->value['updated_at']) {?>
                    <?php echo $_smarty_tpl->tpl_vars['question']->value['updated_at'];?>

                <?php } else { ?>
                    <?php echo $_smarty_tpl->tpl_vars['question']->value['created_at'];?>

                <?php }?>
            </span>
        </span>
        <span>
            <i class = "glyphicon glyphicon-comment"></i>
            <span class = "question-answers"><?php echo $_smarty_tpl->tpl_vars['question']->value['number_answers'];?>
 answer<?php if ($_smarty_tpl->tpl_vars['question']->value['number_answers']!=1) {?>s<?php }?></span>
        </span>
    </div>
</div>
<?php }} ?>
