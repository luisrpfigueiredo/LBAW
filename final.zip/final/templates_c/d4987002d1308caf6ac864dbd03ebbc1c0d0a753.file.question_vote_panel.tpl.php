<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 12:17:57
         compiled from "/home/vagrant/feup/LBAW/final/templates/questions/partials/question_vote_panel.tpl" */ ?>
<?php /*%%SmartyHeaderCode:119617510857547f2ad131b7-94600243%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd4987002d1308caf6ac864dbd03ebbc1c0d0a753' => 
    array (
      0 => '/home/vagrant/feup/LBAW/final/templates/questions/partials/question_vote_panel.tpl',
      1 => 1465301778,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '119617510857547f2ad131b7-94600243',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_57547f2ad21b20_84774638',
  'variables' => 
  array (
    'question' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57547f2ad21b20_84774638')) {function content_57547f2ad21b20_84774638($_smarty_tpl) {?><blockquote class="vote-up-down text-right">
    <div class="vote chev" data-type="q" data-id="<?php echo $_smarty_tpl->tpl_vars['question']->value['id'];?>
" data-url="<?php echo url('api/votes/vote');?>
">
        <div class="increment up<?php if ($_smarty_tpl->tpl_vars['question']->value['voted']==1) {?> active<?php }?>"></div>
        <div class="increment down<?php if ($_smarty_tpl->tpl_vars['question']->value['voted']==-1) {?> active<?php }?>"></div>

        <div class="count vote-count value" data-url="<?php echo url('api/votes/refresh');?>
">
            <?php echo $_smarty_tpl->tpl_vars['question']->value['votes'];?>

        </div>
    </div>
</blockquote><?php }} ?>
