<?php /* Smarty version Smarty-3.1.15, created on 2016-05-20 14:24:39
         compiled from "/home/vagrant/feup/LBAW/final/templates/dev.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1471207262573f1e27d2aeb9-30793954%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c0525079ea2840f6bc824397bccd21d92e554ffc' => 
    array (
      0 => '/home/vagrant/feup/LBAW/final/templates/dev.tpl',
      1 => 1461890617,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1471207262573f1e27d2aeb9-30793954',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_573f1e27d6e3f1_00179724',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_573f1e27d6e3f1_00179724')) {function content_573f1e27d6e3f1_00179724($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('common/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<div class = "container">
    <img style = "max-width: 100%" src = "http://www.mindoors.net/under_dev.jpg" alt = "Under Development">
</div>

<?php echo $_smarty_tpl->getSubTemplate ('common/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>
